# K.G.N. Fashion Zone Android

Generated with Google Bubblewrap core 1.25.0 for the existing K.G.N. customer PWA.

- Application ID: `io.github.waquarahmad622_lgtm.kgnfashionzone`
- Version: `1.0.0` (code `1`)
- Android: API 24 and later; target / compile API 36
- Start URL: `https://waquarahmad622-lgtm.github.io/kgn-fashion-zone/index.html`
- No advertising, billing, location, contacts, SMS, or notification permission is added.

Use JDK 17 and the Android SDK. Run `./gradlew bundleRelease assembleRelease lintRelease`.
The resulting bundles/APKs are unsigned. Sign them outside this public repository with the
owner's private upload key. Never commit keystores or signing passwords.

Before production, host Digital Asset Links at the origin root:
`https://waquarahmad622-lgtm.github.io/.well-known/assetlinks.json`.
Include both the direct APK certificate and Google Play's **app signing** certificate.
This is distinct from the upload certificate. Without verification, Android opens
the site in a Custom Tab with the browser bar instead of a verified TWA.

Play Console setup, privacy disclosures and physical-device testing must be completed
before public release. In particular, test Android Back, Gmail/mailto, WhatsApp,
SMS sharing, catalogue search, enquiry totals, offline startup and all three languages.

For updates, preserve application ID and upload key; increment versionCode.

package io.github.waquarahmad622_lgtm.kgnfashionzone;



public class DelegationService extends
        com.google.androidbrowserhelper.trusted.DelegationService {
    @Override
    public void onCreate() {
        super.onCreate();

        
    }
}

